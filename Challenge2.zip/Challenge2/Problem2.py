import matplotlib.pyplot as plt
import numpy as np
import pandas as pa

file = open('fund_dataset','r')
print(file.read())
#I have took a sample data of first 10 companies to plot chart

table = pa.read_csv('Fundsreport.csv')
print(table)
weight_percentage = [0.12,0.22,0.78,0.1,0.1,0.11,0.29,0.58,1.02,0.27]
plt.xticks(np.arange(1,9), table['etf_name'], rotation=90)
plt.xlabel("weight_percetage")
plt.ylabel("percentage")
plt.bar(x=np.arange(0,2),height=['weight_percetage'],color='r')

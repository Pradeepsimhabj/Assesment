from selenium import webdriver as wd
from selenium.webdriver.support.ui import Select
import pandas as pa
import os

driver = wd.Firefox(executable_path = 'E:\geckodriver-v0.26.0-win64\geckodriver')

driver.get('https://www.nseindia.com/products/content/equities/equities/eq_security.htm')
wait = driver.implicitly_wait(5)

driver.find_element_by_id('symbol').send_keys('YESBANK')
driver.implicitly_wait(5)

select = Select(driver.find_element_by_id('series'))
select.select_by_visible_text('EQ')

driver.find_element_by_id('rdPeriod').click()
select = Select(driver.find_element_by_id('dateRange'))
select.select_by_visible_text('3 months')

driver.find_element_by_id('get').click()

driver.find_element_by_class_name('download-data-link').click()
driver.close()
os.getcwd()
print(os.listdir(os.getcwd()))
df = pa.read_csv('08-09-2019-TO-06-12-2019YESBANKEQN (1).csv')
print(df)